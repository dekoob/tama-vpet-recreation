package model;

import observer.*;
import state.*;

import java.util.*;

public class VirtualPet {

    private int hunger;    // 0 = full, 100 = starving
    private int energy;    // 0 = exhausted, 100 = fully rested
    private int mood;      // 0 = sad, 100 = happy

    private PetState state;
    private final List<PetObserver> observers;

    public VirtualPet(PetState initialState) {
        this.hunger = 50;
        this.energy = 50;
        this.mood = 50;
        this.state = initialState;
        this.observers = new ArrayList<>();
        this.attach(new PetStatusLogger());
    }

    // --- Stats Access ---
    public int getHunger() {
        return hunger;
    }

    public int getEnergy() {
        return energy;
    }

    public int getMood() {
        return mood;
    }
    // --- Setter ---
    public void setHunger(int amount) {
        this.hunger = amount;
    }
    public void setEnergy(int amount) {
        this.energy = amount;
    }
    public void setMood(int amount) {
        this.mood = amount;
    }


    // --- State ---
    public void setState(PetState state) {
        this.state = state;
//        notifyObservers();
    }

    public PetState getState() {
        return state;
    }

    // --- Stat Updates ---
    public void feed() {
        hunger = Math.max(0, hunger - 20);
        mood = Math.min(100, mood + 10);
        notifyObservers();
    }

    public void play() {
        energy = Math.max(0, energy - 15);
        mood = Math.min(100, mood + 15);
        hunger = Math.min(100, hunger + 10);
        notifyObservers();
    }

    public void rest() {
        energy = Math.min(100, energy + 20);
        hunger = Math.min(100, hunger + 5);
        notifyObservers();
    }



    // --- Observer Pattern ---
    public void attach(PetObserver observer) {
        observers.add(observer);
    }

    public void detach(PetObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (PetObserver observer : observers) {
            observer.update(this);
        }
    }

    public void checkState() {
        if (hunger >= 90) {
            this.setState(new SickState());
        } else if (hunger > 70 || energy < 30) {
            this.setState(new HungryState());
        } else if (hunger < 50 && energy > 40) {
            this.setState(new HappyState());
        }
    }

    // PART OF THE GAME LOOP
    public void updateStats() {
        hunger = Math.min(100, hunger + 5);    // gets hungrier
        energy = Math.max(0, energy - 5);      // gets tired
        mood = Math.max(0, mood - 3);          // mood drops slowly
        state.respond(this);                   // delegate state-specific behavior
        checkState();
        notifyObservers();
    }

}
