package state;

import model.VirtualPet;

public class HappyState implements PetState{
    @Override
    public void respond(VirtualPet pet){
        int newMood = Math.max(0, pet.getMood() - 1);
        pet.setMood(newMood);
    }
    @Override
    public String getStateName() {
        return "happy";
    }

}
