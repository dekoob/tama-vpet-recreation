package state;

import model.VirtualPet;

//public class SleepyState implements PetState{
//    @Override
//    public void respond(VirtualPet pet){
//        pet.setMood("Sleepy");
//    }
//    public String getName(){
//        return "Sleepy";
//    }
//    public PetState nextState(){
//        //if low hunger & high energy -> happy state
//        if(pet.getHunger<=5 && pet.getEnergy>=5){
//            return new HappyState();
//        }
//        //if high hunger & low energy -> sick state
//        if(pet.getHunger>5 && pet.getEnergy<5){
//            return new SickState();
//        }
//        //if only high hunger -> hungry state
//        if(pet.getHunger>5){
//            return new HungryState();
//        }
//        //no change -> return same state
//        return this;
//    }
//}
