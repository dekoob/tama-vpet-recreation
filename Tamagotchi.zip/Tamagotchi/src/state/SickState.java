package state;

import model.VirtualPet;

public class SickState implements PetState {
    @Override
    public void respond(VirtualPet pet){
        int newEnergy = Math.max(0, pet.getEnergy() - 10);
        int newMood = Math.max(0, pet.getMood() - 10);
        pet.setEnergy(newEnergy);
        pet.setEnergy(newMood);
    }
    @Override
    public String getStateName() {
        return "sick";
    }

}
