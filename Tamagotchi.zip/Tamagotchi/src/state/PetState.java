package state;

import model.VirtualPet;

public interface PetState {
    // called after state change/action
    void respond(VirtualPet Pet);

    // call state name
    String getStateName();

}
