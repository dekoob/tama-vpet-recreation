package state;

import model.VirtualPet;

public class HungryState implements PetState{
    @Override
    public void respond(VirtualPet pet){
        int newMood = Math.max(0, pet.getMood() - 2);
        pet.setEnergy(newMood);
    }
    @Override
    public String getStateName() {
        return "hungry";
    }

}
