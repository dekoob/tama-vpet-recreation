package actions;

public interface PetAction {
//    public void execute(VirtualPet pet);
}
