package observer;

import model.VirtualPet;

public class UIUpdater implements PetObserver{
    @Override
    public void update(VirtualPet pet) {

    }
}
