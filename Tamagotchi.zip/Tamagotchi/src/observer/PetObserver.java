package observer;

import model.VirtualPet;

public interface PetObserver {
    void update(VirtualPet pet);
}
