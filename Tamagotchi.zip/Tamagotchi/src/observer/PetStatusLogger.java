package observer;

import model.VirtualPet;

public class PetStatusLogger implements PetObserver {

    private VirtualPet pet;

    @Override
    public void update(VirtualPet pet) {
        this.pet = pet;
        System.out.println("===Pet Status===");
        System.out.println("State: " + pet.getState().getStateName());
        System.out.println("Hunger: " + pet.getHunger());
        System.out.println("Energy: " + pet.getEnergy());
        System.out.println("Mood: " + pet.getMood());
        System.out.println("================");
    }
}
