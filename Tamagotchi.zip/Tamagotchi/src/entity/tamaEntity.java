package entity;

import model.VirtualPet;

import java.awt.image.BufferedImage;

public class tamaEntity {

    public int x, y;
    public BufferedImage neutral, happy, sad, hungry, sick, eating, playing, resting, hand;
    public String state;
    public VirtualPet vPet;

}
