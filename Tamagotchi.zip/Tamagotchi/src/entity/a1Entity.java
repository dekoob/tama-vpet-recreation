package entity;

import main.GamePanel;
import main.KeyHandler;
import model.VirtualPet;
import state.HappyState;
import state.PetState;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Objects;

public class a1Entity extends tamaEntity{

    GamePanel gp;
    KeyHandler keyH;

    // to update stats every 25 frames
    int lastStatDecayFrame = 0;
    final int statDecayInterval = 25;


    public a1Entity(GamePanel gp, KeyHandler keyH) {

        this.gp = gp;
        this.keyH = keyH;
        this.vPet = new VirtualPet(new HappyState());

        setDefaultValues();
        getPlayerImage();
    }
    public void setDefaultValues() {

        x = 128;
        y = 128;
        state = vPet.getState().getStateName();
    }
    public void getPlayerImage() {
        try {

            happy = ImageIO.read(getClass().getResourceAsStream("/tama/tama_happy.png"));
            neutral = ImageIO.read(getClass().getResourceAsStream("/tama/tama_neutral.png"));
            sad = ImageIO.read(getClass().getResourceAsStream("/tama/tama_sad.png"));
            hungry = ImageIO.read(getClass().getResourceAsStream("/tama/tama_drooling.png"));
            eating = ImageIO.read(getClass().getResourceAsStream("/tama/tama_eating.png"));
            sick = ImageIO.read(getClass().getResourceAsStream("/tama/tama_sick.png"));
            playing = ImageIO.read(getClass().getResourceAsStream("/tama/tama_urushi.png"));
            resting = ImageIO.read(getClass().getResourceAsStream("/tama/tama_sleeping.png"));
            hand = ImageIO.read(getClass().getResourceAsStream("/hand.png"));


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void update() {

        // delay interval: to update every 50 frames
        if (lastStatDecayFrame++ >= statDecayInterval) {
            vPet.updateStats();
            lastStatDecayFrame = 0;
        }



        state = vPet.getState().getStateName();

        if (keyH.aPressed == true) {
            state = "happy";
            vPet.setState(new HappyState());
        }
        else if(keyH.fPressed == true) {
            state = "eating";
            vPet.feed();
        }
        else if(keyH.pPressed == true) {
            state = "playing";
            vPet.play();
        }
        else if(keyH.rPressed == true) {
            state = "resting";
            vPet.rest();
        }
    }
    public void draw(Graphics2D g2) {

//        g2.setColor(Color.white);
//        g2.fillRect(x, y, gp.tileSize, gp.tileSize);

        BufferedImage image = neutral;

        switch(state) {
            case "happy":
                image = happy;
                break;
            case "hungry":
                image = hungry;
                break;
            case "eating":
                image = eating;
                break;
            case "playing":
                image = playing;
                g2.drawImage(hand, x+256, y-64, gp.tileSize/2, gp.tileSize/2, null);
                break;
            case "sick":
                image = sick;
                break;
            case "resting":
                image = resting;
                break;


        }
        g2.drawImage(image, x, y, gp.tileSize, gp.tileSize, null);
    }
}
