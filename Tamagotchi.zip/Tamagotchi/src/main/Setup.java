package main;

import java.util.Scanner;

import decorator.*;

public class Setup {

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PINK = "\u001B[95m";
    public static final String ANSI_YELLOW = "\u001B[33m";

    public static void preLaunchSetUp() {

        Scanner sc = new Scanner(System.in);

        PetEnvironment room = new BasicRoom();
        DressEnvironment dress = new PlainTama();

        // Step1: Choose TreeSystem.out.println("Step 1: Choose your Tree:");

        System.out.println("1) Small Tree  2) Big Tree  3) No Tree");
        int treechoice = sc.nextInt();
        if (treechoice == 1) room = new PlantDecorator(room,"small");
        else if(treechoice == 2) room = new PlantDecorator(room,"big");

        System.out.println("Step 2: Choose your wallpaper:");
        System.out.println("1) Shiny  2) Neon  3) No wallpaper");
        int wallChoice = sc.nextInt();
        if (wallChoice == 1) room = new WallpaperDecorator(room, "shiny");
        else if (wallChoice == 2) room = new WallpaperDecorator( room, "neon");

        System.out.println("Step 3: Choose your outfit:");
        System.out.println("1) Casual  2) Classy  3) Plain");
        int dressChoice = sc.nextInt();
        if(dressChoice == 1) dress = new DressDecorator(dress, "casual");
        else if(dressChoice == 2) dress = new DressDecorator(dress, "classy");

        System.out.println("Step 4: Choose your hat:");
        System.out.println("1) Vintage  2) Classy  3) Plain");
        int hatChoice = sc.nextInt();
        if(hatChoice == 1) dress = new HatDecorator(dress, "vintage");
        else if(hatChoice == 2) dress = new HatDecorator(dress, "classy");

        System.out.println(ANSI_BLUE + "00"+ANSI_RESET+room.describe()+ANSI_BLUE+"00");
        System.out.println(ANSI_PINK+ "00"+ANSI_RESET+ dress.describeDress()+ANSI_PINK+"00");
        System.out.println(ANSI_YELLOW+"\nAll done! It is time to greet your tamagotchi."+ANSI_RESET);

        sc.close();
    }
}
