package decorator;


public class DressDecorator extends TamaDecorator {
    private String dressType;
    public DressDecorator(DressEnvironment dress, String dresstype){
        super(dress);
        this.dressType = dresstype;
    }
    public String describeDress(){
        String dressDesc = "";
        if(dressType.equalsIgnoreCase("casual")){
            dressDesc = " wearing a comfy top and cool jeans ";
        }
        else if(dressType.equalsIgnoreCase("classy")){
            dressDesc = " dressed in a lovely silk gown with fine details ";
        }
        return super.describeDress() + dressDesc;
    }
}
