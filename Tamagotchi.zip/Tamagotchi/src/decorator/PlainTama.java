package decorator;


public class PlainTama implements DressEnvironment {
    public String describeDress(){
        return "The pet has fluffy fur";
    }
}
