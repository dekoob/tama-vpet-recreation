package decorator;


public class BasicRoom implements PetEnvironment{
    public String describe(){
        return "The pet lives in a cozy empty Room";
    }
}
