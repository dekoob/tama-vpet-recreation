package decorator;


public abstract class RoomDecorator implements PetEnvironment {
    protected PetEnvironment baseRoom;
    public RoomDecorator(PetEnvironment room){
        this.baseRoom = room;
    }
    public String describe(){
        return baseRoom.describe();
    }
}
