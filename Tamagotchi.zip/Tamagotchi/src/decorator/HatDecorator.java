package decorator;


public class HatDecorator extends TamaDecorator {
    private String hatType;
    public HatDecorator(DressEnvironment dress, String hattype){
        super(dress);
        this.hatType = hattype;
    }
    public String describeDress(){
        String hatDesc = "";
        if(hatType.equalsIgnoreCase("vintage")){
            hatDesc = " topped with a charming vintage hat.";
        }
        else if(hatType.equalsIgnoreCase("classy")){
            hatDesc = " wearing a glamorous high-society hat.";
        }
        return super.describeDress()+ hatDesc;
    }
}
