package decorator;
public interface PetEnvironment{
    String describe();
}
