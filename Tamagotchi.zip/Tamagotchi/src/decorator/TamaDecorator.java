package decorator;


public abstract class TamaDecorator implements DressEnvironment {
    protected DressEnvironment baseDress;
    public TamaDecorator(DressEnvironment dress){
        this.baseDress = dress;
    }
    public String describeDress(){
        return baseDress.describeDress();
    }
}
