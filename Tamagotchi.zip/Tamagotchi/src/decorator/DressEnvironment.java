package decorator;


public interface DressEnvironment {
    String describeDress();
}
