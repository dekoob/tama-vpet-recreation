package decorator;

public class WallpaperDecorator extends RoomDecorator {
    private String wallpaperType;
    public WallpaperDecorator(PetEnvironment room, String wallpapertype){
        super(room);
        this.wallpaperType = wallpapertype;
    }
    public String describe(){
        String wallDesc = "";
        if(wallpaperType.equalsIgnoreCase("shiny")){
            wallDesc = "and a shimmer wallpaper with elegant golden wallpaper.";
        }
        else if(wallpaperType.equalsIgnoreCase("neon")){
            wallDesc = "and a neon wallpaper glow with futuristic vibes.";
        }
        return super.describe()+ wallDesc;
    }
}
