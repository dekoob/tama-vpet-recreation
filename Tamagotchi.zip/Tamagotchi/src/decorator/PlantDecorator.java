package decorator;


public class PlantDecorator extends RoomDecorator {
    private String treeType;
    public PlantDecorator(PetEnvironment room, String treetype){
        super(room);
        this.treeType = treetype;
    }
    public String describe(){
        String treeDesc = "";
        if(treeType.equalsIgnoreCase("small")){
            treeDesc = " with a tiny bonsai tree that adds a touch of calm ";
        }
        else if(treeType.equalsIgnoreCase("big")){
            treeDesc = " with a grand leafy tree that fills the corner of the room ";
        }
        return super.describe()+treeDesc;
       
    }
}
